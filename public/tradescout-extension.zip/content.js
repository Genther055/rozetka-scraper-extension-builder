// TradeScout Content Script v3.5 Pro (Multi-Tab Background Worker & Strict 60-Items/Page Scraper)
(function() {
    if (window.self !== window.top) return; // Skip iframes
    if (window.__tradeScoutInjected) return; // Prevent duplicate injection
    window.__tradeScoutInjected = true;

    console.log('TradeScout Content Script v3.5 Pro loaded on:', window.location.href);

    let isTabScrapingActive = false;
    window.__tradeScoutIsScrapingActive = false;
    let currentSessionId = null;
    let currentTabId = null;
    let webhookEndpoint = 'https://rozetka-scraper-extension-builder.onrender.com/api/products';
    const sentLinks = new Set();
    let sessionStartTime = null;
    let currentPercent = 0;
    let currentEstimatedTotal = 0;
    let currentStatusMsg = 'Готова до запуску';
    let currentPage = 1;

    // Helper to send messages safely to background service worker
    function sendTabMessage(msg) {
        if (msg.action === 'tabProgress' && (!isTabScrapingActive || !window.__tradeScoutIsScrapingActive)) {
            return; // Block progress messages if scraping has stopped
        }
        try {
            chrome.runtime.sendMessage({ ...msg, tabId: currentTabId }, () => {
                if (chrome.runtime.lastError) {}
            });
        } catch (e) {}
    }

    // Extract human-readable category & session title from page
    function getPageMetadata() {
        let title = '';
        const h1 = document.querySelector('h1');
        if (h1 && h1.innerText && h1.innerText.trim().length > 2) {
            title = h1.innerText.trim();
        } else {
            const rawTitle = document.title || '';
            title = rawTitle.split(/[-–—|]/)[0].replace(/купити|в києві|україна|ціни|rozetka/gi, '').trim() || 'Каталог товарів';
        }

        let category = 'Загальна';
        const breadcrumbs = document.querySelectorAll('.breadcrumbs__link, .breadcrumbs__last, [class*="breadcrumbs"] a');
        if (breadcrumbs.length > 0) {
            const lastBc = breadcrumbs[breadcrumbs.length - 1];
            if (lastBc && lastBc.innerText) category = lastBc.innerText.trim();
        } else if (title) {
            category = title;
        }

        return { title, category };
    }

    function parseCountFromText(text) {
        if (!text || typeof text !== 'string') return 0;
        const cleaned = text.replace(/&nbsp;/g, ' ').replace(/\u00A0/g, ' ').replace(/\u202F/g, ' ').trim();
        
        // Match: "Знайдено 508 товарів" or "Знайдено 355 товарів"
        const m1 = cleaned.match(/(?:знайдено|найдено)\s*([\d\s\u00A0\u202F.,]+)\s*(?:товар|тов)/i);
        if (m1 && m1[1]) {
            const num = parseInt(m1[1].replace(/[\s\u00A0\u202F.,]/g, ''), 10);
            if (!isNaN(num) && num > 0 && num < 1000000) return num;
        }

        // Match: "508 товарів"
        const m2 = cleaned.match(/\b([\d\s\u00A0\u202F.,]+)\s*(?:товарів|товари|товаров|товара)\b/i);
        if (m2 && m2[1]) {
            const num = parseInt(m2[1].replace(/[\s\u00A0\u202F.,]/g, ''), 10);
            if (!isNaN(num) && num > 0 && num < 1000000) return num;
        }

        // Match: "Знайдено 508"
        const m3 = cleaned.match(/(?:знайдено|найдено)\s*([\d\s\u00A0\u202F.,]+)/i);
        if (m3 && m3[1]) {
            const num = parseInt(m3[1].replace(/[\s\u00A0\u202F.,]/g, ''), 10);
            if (!isNaN(num) && num > 0 && num < 1000000) return num;
        }

        return 0;
    }

    function getEstimatedTotalFromPage() {
        // Priority 1: Top catalog counter text (e.g. "Знайдено 508 товарів")
        const topElements = document.querySelectorAll('rz-catalog-settings, .catalog-settings, .catalog-heading, .catalog-selection, [data-testid*="found"], [data-testid*="counter"], [class*="found-goods"], [class*="goods-count"], [class*="heading__goods"], .catalog-selection__label, h1, h2, p, span, div');
        for (const el of topElements) {
            if (el.children.length > 5) continue;
            const txt = (el.textContent || el.innerText || '').trim();
            if (txt.toLowerCase().includes('знайдено') || txt.toLowerCase().includes('найдено') || txt.toLowerCase().includes('товар')) {
                const count = parseCountFromText(txt);
                if (count > 0 && count < 1000000) return count;
            }
        }

        // Priority 2: Check pagination links - find the real last page
        try {
            const pageLinks = document.querySelectorAll('a.pagination__link, [class*="pagination"] a, li.pagination__item a');
            let maxPage = 1;
            pageLinks.forEach(link => {
                const txt = (link.textContent || '').trim();
                const num = parseInt(txt, 10);
                if (!isNaN(num) && num > maxPage && num < 500) {
                    maxPage = num;
                }
                const href = link.getAttribute('href') || '';
                const m = href.match(/page=(\d+)/i) || href.match(/\/(\d+)\/?$/);
                if (m && m[1]) {
                    const hNum = parseInt(m[1], 10);
                    if (!isNaN(hNum) && hNum > maxPage && hNum < 500) {
                        maxPage = hNum;
                    }
                }
            });
            if (maxPage > 1) {
                return maxPage * 60;
            }
        } catch (e) {}

        const currentDomTiles = document.querySelectorAll('rz-product-tile, .goods-tile, rz-catalog-tile, [data-goods-id]').length;
        return currentDomTiles > 0 ? currentDomTiles : 60;
    }

    // Strict filter: eliminate carousels, sliders, accessories, sidebars, banners, recommendation widgets, and ads
    function isUnwantedTile(item) {
        if (!item || !(item instanceof Element)) return true;
        
        // 1. Check all possible slider / carousel / recommendation / sidebar / accessories containers
        if (item.closest('rz-goods-carousel, rz-carousel, rz-goods-slider, rz-slider, app-goods-carousel, app-slider, .goods-carousel, .recently-viewed, rz-goods-section-slider, .slider, .carousel, rz-similar-goods, rz-recommended-goods, rz-viewed-goods, .catalog-banner, .advertising-slot, aside, .sidebar, rz-accessories, .goods-slider, .recommendations, [data-testid*="carousel"], [data-testid*="slider"], [class*="carousel"], [class*="slider"], [class*="section-slider"], rz-product-slider, .main-goods__cell--advertising')) {
            return true;
        }
        
        // 2. Check if tile itself is a banner, advertising slot, or marked as advert/sponsored
        const tileClasses = (item.className || '').toLowerCase();
        if (
            tileClasses.includes('catalog-banner') || 
            tileClasses.includes('rz-banner') || 
            tileClasses.includes('banner-tile') || 
            tileClasses.includes('advertising') || 
            tileClasses.includes('advert') || 
            tileClasses.includes('promoted') || 
            tileClasses.includes('sponsored') ||
            item.hasAttribute('data-ad') ||
            item.hasAttribute('data-advertisement') ||
            item.hasAttribute('data-sponsored') ||
            item.hasAttribute('data-advert') ||
            item.hasAttribute('data-promo-id') ||
            item.hasAttribute('data-adv')
        ) {
            return true;
        }

        // 3. Check for promo/ad labels, badges, or text anywhere inside tile
        const promoElements = item.querySelectorAll('.goods-tile__label, .promo-label, [data-testid*="promo-label"], [data-testid*="advert"], [class*="promo-label"], [class*="advert"], [class*="sponsored"], [class*="promoted"], .goods-tile__badge, [class*="badge"]');
        for (const el of promoElements) {
            const txt = (el.textContent || '').trim().toLowerCase();
            if (/(?:^|\s|\b)(?:реклама|спонсор|спонсорський|спонсоровано|ad|ads|sponsored|promoted)(?:\s|$|\b|[.,!?:])/i.test(txt)) {
                return true;
            }
        }

        // 4. Fallback check: if any text inside tile explicitly states "реклама" or "спонсорський"
        const innerText = (item.innerText || '').toLowerCase();
        if (/(?:^|\s|\b)(?:реклама|спонсорський|спонсорский|спонсоровано)(?:\s|$|\b|[.,!?:])/i.test(innerText)) {
            return true;
        }

        const hasProductLink = !!item.querySelector('a[href*="/p/"], a[href*="/p-"], a[href*="/p"], a.goods-tile__heading, a.tile-title, [class*="heading"] a');
        const hasPrice = !!item.querySelector('.goods-tile__price, .price, [class*="price"]');
        if (!hasProductLink && !hasPrice) return true;

        return false;
    }

    async function silentBackgroundScroll() {
        try {
            const totalHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
            const viewH = window.innerHeight || 800;
            const steps = [0.25, 0.50, 0.75, 1.0];
            for (const step of steps) {
                const targetY = Math.max(0, Math.round((totalHeight - viewH) * step));
                window.scrollTo({ top: targetY, behavior: 'auto' });
                window.dispatchEvent(new Event('scroll'));
                await new Promise(r => setTimeout(r, 120));
            }
        } catch (_) {}
    }

    function findPaginationActionElements(pageIndex) {
        const retrySelectors = [
            'button.retry',
            'button[class*="retry"]',
            'a[class*="retry"]',
            'rz-empty-state button',
            '.error-state button',
            '[class*="error"] button'
        ];
        for (const sel of retrySelectors) {
            try {
                const btn = document.querySelector(sel);
                if (btn) return { type: 'retry', element: btn };
            } catch (e) {}
        }

        const moreSelectors = [
            'rz-catalog-more button', 
            '.catalog-more button', 
            '.catalog-more__btn', 
            'button.show-more', 
            '.show-more', 
            'a.show-more', 
            '[class*="catalog-more"] button',
            '[class*="catalog-more"] a',
            '[class*="show-more"]',
            'button[data-testid="show-more"]'
        ];
        for (const sel of moreSelectors) {
            try {
                const btn = document.querySelector(sel);
                if (btn && !btn.disabled && !btn.classList.contains('button--loading') && !btn.classList.contains('disabled')) {
                    return { type: 'showMore', element: btn };
                }
            } catch (e) {}
        }

        const nextSelectors = [
            'a.pagination__direction--forward',
            'a.pagination__direction_type_forward',
            '[class*="pagination__direction--forward"]',
            '[class*="pagination__direction_type_forward"]',
            'a[title*="Наступна"]',
            'a[title*="Следующая"]',
            'a[aria-label*="Next"]',
            'rz-paginator a.pagination__direction:last-child',
            'a.pagination__direction:last-child'
        ];
        for (const sel of nextSelectors) {
            try {
                const btn = document.querySelector(sel);
                if (btn && !btn.disabled && !btn.classList.contains('disabled') && !btn.classList.contains('pagination__direction--disabled')) {
                    const href = btn.getAttribute('href') || '';
                    return { type: 'nextPage', element: btn, href };
                }
            } catch (e) {}
        }

        const nextPageNum = pageIndex + 1;
        const pageNumSelectors = [
            `a.pagination__link[href*="page=${nextPageNum}"]`,
            `a.pagination__link[href*="page=${nextPageNum}/"]`,
            `a.pagination__link[href*=";page=${nextPageNum}"]`,
            `a.pagination__link`,
            `[class*="pagination__item"] a`
        ];
        for (const sel of pageNumSelectors) {
            try {
                const links = document.querySelectorAll(sel);
                for (const link of links) {
                    const txt = (link.innerText || link.textContent || '').trim();
                    const href = link.getAttribute('href') || '';
                    if (txt === String(nextPageNum) || href.includes(`page=${nextPageNum}`)) {
                        return { type: 'pageNum', element: link, pageNum: nextPageNum, href };
                    }
                }
            } catch (e) {}
        }

        const allElements = document.querySelectorAll('button, a, div[role="button"], span');
        for (const el of allElements) {
            const txt = (el.innerText || el.textContent || '').trim().toLowerCase();
            if (txt === 'показати ще' || txt === 'показать еще' || txt.includes('показати ще') || txt.includes('показать еще') || txt === 'show more') {
                if (el.closest('.sidebar') || el.closest('.filter') || el.closest('.recently-viewed')) continue;
                if (el.disabled || el.classList.contains('button--loading') || el.classList.contains('disabled')) continue;
                return { type: 'showMore', element: el };
            }
            if (txt === 'спробувати ще' || txt === 'повторити' || txt.includes('спробувати знову') || txt.includes('повторити спробу')) {
                return { type: 'retry', element: el };
            }
        }

        return null;
    }

    function dispatchSafeClick(element) {
        if (!element) return;
        try {
            element.click();
            element.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
        } catch (_) {}
    }

    async function sendWebhookPayload(payload) {
        return new Promise(resolve => {
            chrome.runtime.sendMessage({
                action: 'sendWebhook',
                webhookUrl: webhookEndpoint,
                tabId: currentTabId,
                payload: payload
            }, (res) => {
                resolve(res?.serverInfo || null);
            });
        });
    }

    function extractSeller(item) {
        if (!item || !(item instanceof Element)) return 'Rozetka';
        
        const sellerSelectors = [
            '.goods-tile__seller',
            '.goods-tile__seller-name',
            'rz-goods-seller',
            'rz-seller',
            '[class*="goods-tile__seller"]',
            '[class*="seller-name"]',
            '[class*="seller-title"]',
            '.seller-title',
            '.seller-name',
            '.shop-name',
            '.goods-tile__shop',
            '[data-testid*="seller"]',
            '[data-testid*="merchant"]',
            '.goods-tile__merchant',
            '[class*="merchant"]'
        ];
        
        for (const sel of sellerSelectors) {
            try {
                const el = item.querySelector(sel);
                if (el && el.innerText && el.innerText.trim().length > 1) {
                    let s = el.innerText.trim();
                    s = s.replace(/^продавець:?\s*/i, '')
                         .replace(/^продавец:?\s*/i, '')
                         .replace(/^seller:?\s*/i, '')
                         .replace(/^магазин:?\s*/i, '')
                         .trim();
                    if (s && s.length > 1 && !s.includes('\n') && s.length < 60) {
                        return s;
                    }
                }
            } catch (_) {}
        }
        
        try {
            const itemText = item.innerText || '';
            const match = itemText.match(/(?:продавець|продавец|seller)\s*:\s*([^\n\r\t,;]+)/i);
            if (match && match[1]) {
                let s = match[1].trim();
                if (s && s.length > 1 && s.length < 60) {
                    return s;
                }
            }
        } catch (_) {}
        
        return 'Rozetka';
    }

    async function scrapeCurrentDomItems(meta, pageIndex) {
        // 1. Locate all catalog tiles flexibly across the page
        const catalogContainer = document.querySelector('rz-grid, ul.catalog-grid, .catalog-grid, rz-catalog-grid, rz-catalog-tiles, .catalog-selection__goods, section.catalog-grid') || document.querySelector('main') || document.body;
        
        let rawTiles = Array.from(catalogContainer.querySelectorAll('li.catalog-grid__cell, rz-catalog-tile, rz-product-tile, [data-goods-id], .goods-tile, app-goods-tile-default'));
        if (rawTiles.length === 0) {
            rawTiles = Array.from(document.querySelectorAll('rz-catalog-tile, rz-product-tile, [data-goods-id], .goods-tile, li.catalog-grid__cell, app-goods-tile-default'));
        }

        // Calculate max items for this page (standard Rozetka catalog page has up to 60 items)
        let maxItemsThisPage = 60;
        if (currentEstimatedTotal > 0 && pageIndex >= Math.ceil(currentEstimatedTotal / 60)) {
            const remainder = currentEstimatedTotal - sentLinks.size;
            if (remainder > 0 && remainder <= 60) {
                maxItemsThisPage = remainder;
            }
        }

        // Filter out unwanted slider/carousel/banner elements and avoid nested child duplicates
        const distinctTiles = [];
        const seenElements = new Set();

        for (const item of rawTiles) {
            if (isUnwantedTile(item)) continue;
            
            const linkTag = item.tagName === 'A' ? item : (item.querySelector('a.goods-tile__heading, a.tile-title, [class*="heading"] a, a[href*="/p/"], a[href*="/p-"], a[href*="/p"]') || item.querySelector('a[href]'));
            if (!linkTag) continue;

            const rawHref = linkTag.getAttribute('href');
            if (!rawHref) continue;

            let link = rawHref.split('?')[0].split('#')[0].replace(/\/+$/, '');
            if (!link.startsWith('http')) {
                link = link.startsWith('/') ? `https://rozetka.com.ua${link}` : `https://rozetka.com.ua/${link}`;
            }

            if (sentLinks.has(link) || seenElements.has(link)) continue;
            seenElements.add(link);
            distinctTiles.push({ item, linkTag, link });

            // Strictly cap at exactly max items needed for this page
            if (distinctTiles.length >= maxItemsThisPage) break;
        }

        if (distinctTiles.length === 0) return [];

        // Batch fetch official Rozetka product details (seller title, exact pricing, old_price, discounts) for all items on this page
        const apiProductMap = new Map();
        try {
            const productIds = [];
            for (const { link } of distinctTiles) {
                const m = link.match(/\/p(\d+)/i) || link.match(/p(\d+)/i) || link.match(/\/(\d{5,})\//);
                if (m && m[1]) productIds.push(m[1]);
            }
            if (productIds.length > 0) {
                const apiUrl = `https://common-api.rozetka.com.ua/v1/api/product/details?country=UA&lang=ua&ids=${productIds.join(',')}`;
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 3500);
                const res = await fetch(apiUrl, { signal: controller.signal }).catch(() => null);
                clearTimeout(timeoutId);
                if (res && res.ok) {
                    const json = await res.json().catch(() => null);
                    if (json && Array.isArray(json.data)) {
                        for (const apiProd of json.data) {
                            if (apiProd && apiProd.id) {
                                apiProductMap.set(String(apiProd.id), apiProd);
                            }
                        }
                    }
                }
            }
        } catch (_) {}

        const newItems = [];

        for (const { item, linkTag, link } of distinctTiles) {
            try {
                const titleEl = item.querySelector('a.tile-title, a.goods-tile__heading, .goods-tile__heading, .tile-title, [class*="heading"], [class*="title"]') || linkTag;
                const name = titleEl && titleEl.innerText ? titleEl.innerText.trim() : (linkTag.innerText ? linkTag.innerText.trim() : '');
                if (!name || name.length < 3) continue;

                const idMatch = link.match(/\/p(\d+)/i) || link.match(/p(\d+)/i) || link.match(/\/(\d{5,})\//);
                const prodId = idMatch ? String(idMatch[1]) : '';
                const apiProd = prodId ? apiProductMap.get(prodId) : null;

                // --- 1. CURRENT PRICE EXTRACTION ---
                let price = 0;
                const priceEl = item.querySelector(
                    '.goods-tile__price-value, .goods-tile__price--current, .goods-tile__price_color_red, ' +
                    '.price--red, .price, [class*="price-value"], [class*="price__current"], [class*="price_color_red"], ' +
                    '.product-price__big, [class*="price__main"]'
                );
                const priceText = priceEl && priceEl.innerText ? priceEl.innerText : '';
                if (priceText) {
                    price = parseInt(priceText.replace(/\D/g, ''), 10) || 0;
                }
                if (!price && apiProd && apiProd.price) {
                    price = parseInt(String(apiProd.price).replace(/\D/g, ''), 10) || 0;
                }

                // --- 2. OLD (PRE-DISCOUNT) PRICE & DISCOUNT EXTRACTION ---
                let oldPrice = 0;
                let discount = 0;

                // A. Official Rozetka API data
                if (apiProd) {
                    if (apiProd.old_price && Number(apiProd.old_price) > 0) {
                        const parsedOld = parseInt(String(apiProd.old_price).replace(/\D/g, ''), 10) || 0;
                        if (parsedOld > price) {
                            oldPrice = parsedOld;
                        }
                    } else if (apiProd.oldPrice && Number(apiProd.oldPrice) > 0) {
                        const parsedOld = parseInt(String(apiProd.oldPrice).replace(/\D/g, ''), 10) || 0;
                        if (parsedOld > price) {
                            oldPrice = parsedOld;
                        }
                    }

                    if (apiProd.discount) {
                        if (typeof apiProd.discount === 'number' && apiProd.discount > 0) {
                            discount = apiProd.discount;
                        } else if (typeof apiProd.discount === 'object' && apiProd.discount.value) {
                            discount = parseInt(apiProd.discount.value, 10) || 0;
                        }
                    }
                }

                // B. DOM Old Price Element Search
                if (!oldPrice) {
                    const oldPriceEl = item.querySelector(
                        '.goods-tile__price--old, .goods-tile__price_type_old, .goods-tile__price.type_old, ' +
                        '.goods-tile__price_color_gray, .goods-tile__price-old, [class*="price_color_gray"], ' +
                        '[class*="price--old"], [class*="price_type_old"], [class*="price-old"], [class*="old-price"], ' +
                        '[class*="price__old"], [class*="old_price"], [class*="price-discount"], [class*="product-price__small"], ' +
                        'del, s, strike, [style*="line-through"]'
                    );
                    if (oldPriceEl && oldPriceEl.innerText) {
                        const parsed = parseInt(oldPriceEl.innerText.replace(/\D/g, ''), 10) || 0;
                        if (parsed > price) {
                            oldPrice = parsed;
                        }
                    }
                }

                // C. DOM Promo Badges / Discount Stickers
                if (!discount) {
                    const badgeEl = item.querySelector(
                        'rz-badge, .goods-tile__badge, [class*="goods-tile__badge"], [class*="goods-tile__label"], ' +
                        '[class*="badge"], [class*="promo"], [class*="discount"], [class*="sticker"], [class*="tag"]'
                    );
                    const badgeText = badgeEl && badgeEl.innerText ? badgeEl.innerText : '';
                    const badgeMatch = badgeText.match(/(?:-|−|знижка\s*|скидка\s*)(\d{1,2})\s*%/i) || badgeText.match(/-(\d{1,2})%/);
                    if (badgeMatch && badgeMatch[1]) {
                        discount = parseInt(badgeMatch[1], 10) || 0;
                    } else {
                        const fullTileText = item.innerText || '';
                        const tileMatch = fullTileText.match(/(?:-|−)(\d{1,2})%/);
                        if (tileMatch && tileMatch[1]) {
                            const pct = parseInt(tileMatch[1], 10) || 0;
                            if (pct > 0 && pct < 90) {
                                discount = pct;
                            }
                        }
                    }
                }

                // D. Harmonize oldPrice & discount
                if (oldPrice > price && !discount && price > 0) {
                    discount = Math.round(((oldPrice - price) / oldPrice) * 100);
                } else if (discount > 0 && (!oldPrice || oldPrice <= price) && price > 0) {
                    oldPrice = Math.round(price / (1 - (discount / 100)));
                }

                if (!oldPrice || oldPrice < price) {
                    oldPrice = price;
                }

                const reviewsEl = item.querySelector('.rating-block-rating, [class*="rating"], [class*="comments"], .goods-tile__reviews-link, [class*="reviews"]');
                const reviewsText = reviewsEl && reviewsEl.innerText ? reviewsEl.innerText : '';
                const reviews = reviewsText ? parseInt(reviewsText.replace(/\D/g, ''), 10) || 0 : 0;

                const starsEl = item.querySelector('.stars_rating, [data-testid="stars-rating"], .goods-tile__stars svg, [class*="stars"] svg');
                let rating = 5.0;
                if (starsEl) {
                    const style = starsEl.getAttribute('style') || '';
                    const match = style.match(/width:\s*calc\(([\d.]+)%/);
                    if (match) rating = parseFloat(((parseFloat(match[1]) || 100) / 20).toFixed(1));
                }

                const itemText = item.innerText || '';
                const inStock = !(item.classList.contains('tile-disabled') || itemText.includes('Немає в наявності'));

                const capacityMatch = name.match(/(\d+)\s*(?:mah|мАг)/i);
                const capacity = capacityMatch ? `${capacityMatch[1]} mAh` : '';
                const powerMatch = name.match(/(\d+(?:\.\d+)?)\s*W/i);
                const power = powerMatch ? `${powerMatch[1]}W` : '';
                const specs = [capacity, power].filter(Boolean).join(', ') || 'Стандартні';

                const apiSeller = apiProd && apiProd.seller ? ((apiProd.seller.title || apiProd.seller.name || '').trim()) : null;
                const seller = apiSeller || extractSeller(item) || 'Rozetka';

                newItems.push({
                    name,
                    price,
                    oldPrice: oldPrice || price,
                    discount,
                    rating,
                    reviews,
                    inStock,
                    category: meta.category,
                    sessionTitle: meta.title,
                    sessionId: currentSessionId,
                    specs,
                    description: '',
                    seller,
                    sellersCount: 1,
                    priceChange: 0,
                    reviewsGrowth: 0,
                    link
                });

                sentLinks.add(link);
            } catch (_) {}
        }

        return newItems;
    }

    // Main scraping runner
    async function runTabScraper(initialPage) {
        const meta = getPageMetadata();
        if (currentEstimatedTotal <= 0) {
            currentEstimatedTotal = getEstimatedTotalFromPage();
        }
        currentPage = initialPage || 1;
        console.log(`TradeScout Tab ${currentTabId}: Started scraping "${meta.title}"... Target: ${currentEstimatedTotal}`);

        currentPercent = Math.min(100, Math.round((sentLinks.size / Math.max(1, currentEstimatedTotal)) * 100)) || 1;
        currentStatusMsg = `Збір: ${meta.title} (${sentLinks.size}/${currentEstimatedTotal})...`;

        let consecutiveNoNew = 0;
        let lastCount = sentLinks.size;
        const tileSelectors = 'ul.catalog-grid, rz-product-tile, .goods-tile, rz-catalog-tile, li.catalog-grid__cell, [data-goods-id]';

        while (isTabScrapingActive && window.__tradeScoutIsScrapingActive) {
            if (currentEstimatedTotal <= 0) {
                const latestEstimated = getEstimatedTotalFromPage();
                if (latestEstimated > 0) {
                    currentEstimatedTotal = latestEstimated;
                }
            }

            // Always reset viewport to TOP at the beginning of every page
            window.scrollTo({ top: 0, behavior: 'auto' });
            window.dispatchEvent(new Event('scroll'));
            await new Promise(r => setTimeout(r, 450));

            // 1. Thoroughly scroll & harvest up to 60 items on the CURRENT page
            let pageHarvestedCount = 0;
            let attemptsWithoutNew = 0;
            const maxAttemptsWithoutNew = 7;
            let expectedPageLimit = 60;
            if (currentEstimatedTotal > 0 && currentPage >= Math.ceil(currentEstimatedTotal / 60)) {
                const rem = currentEstimatedTotal - sentLinks.size;
                if (rem > 0 && rem <= 60) {
                    expectedPageLimit = rem;
                }
            }

            // Harvest initially visible items first
            const initialProducts = await scrapeCurrentDomItems(meta, currentPage);
            if (initialProducts.length > 0) {
                pageHarvestedCount += initialProducts.length;

                currentPercent = Math.min(100, Math.round((sentLinks.size / Math.max(1, currentEstimatedTotal)) * 100));
                currentStatusMsg = `Зібрано ${sentLinks.size} з ${currentEstimatedTotal} товарів (стор. ${currentPage})...`;

                sendTabMessage({
                    action: 'tabProgress',
                    total: sentLinks.size,
                    page: currentPage,
                    percent: currentPercent,
                    statusMsg: currentStatusMsg,
                    syncedCount: sentLinks.size,
                    estimatedTotal: currentEstimatedTotal,
                    sessionTitle: meta.title,
                    category: meta.category,
                    sessionId: currentSessionId,
                    startTime: sessionStartTime
                });

                await sendWebhookPayload({
                    products: initialProducts,
                    page: currentPage,
                    sessionId: currentSessionId,
                    sessionTitle: meta.title,
                    category: meta.category,
                    tabId: currentTabId
                });
            }

            while (isTabScrapingActive && window.__tradeScoutIsScrapingActive && pageHarvestedCount < expectedPageLimit && attemptsWithoutNew < maxAttemptsWithoutNew) {
                // Progressive scroll down to trigger Rozetka's IntersectionObserver & lazy loading
                const totalHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
                const viewH = window.innerHeight || 800;
                
                const scrollPcts = [0.25, 0.5, 0.75, 1.0];
                for (const pct of scrollPcts) {
                    if (!isTabScrapingActive || !window.__tradeScoutIsScrapingActive) break;
                    const targetY = Math.max(0, Math.round((totalHeight - viewH) * pct));
                    window.scrollTo({ top: targetY, behavior: 'smooth' });
                    window.dispatchEvent(new Event('scroll'));
                    await new Promise(r => setTimeout(r, 180));
                }

                // Scroll to absolute bottom and wait for Rozetka lazy-load network request & DOM render
                window.scrollTo({ top: totalHeight, behavior: 'smooth' });
                window.dispatchEvent(new Event('scroll'));
                await new Promise(r => setTimeout(r, 650));

                if (!isTabScrapingActive || !window.__tradeScoutIsScrapingActive) break;

                const stepProducts = await scrapeCurrentDomItems(meta, currentPage);
                if (stepProducts.length > 0) {
                    attemptsWithoutNew = 0;
                    pageHarvestedCount += stepProducts.length;

                    currentPercent = Math.min(100, Math.round((sentLinks.size / Math.max(1, currentEstimatedTotal)) * 100));
                    currentStatusMsg = `Зібрано ${sentLinks.size} з ${currentEstimatedTotal} товарів (стор. ${currentPage})...`;

                    sendTabMessage({
                        action: 'tabProgress',
                        total: sentLinks.size,
                        page: currentPage,
                        percent: currentPercent,
                        statusMsg: currentStatusMsg,
                        syncedCount: sentLinks.size,
                        estimatedTotal: currentEstimatedTotal,
                        sessionTitle: meta.title,
                        category: meta.category,
                        sessionId: currentSessionId,
                        startTime: sessionStartTime
                    });

                    await sendWebhookPayload({
                        products: stepProducts,
                        page: currentPage,
                        sessionId: currentSessionId,
                        sessionTitle: meta.title,
                        category: meta.category,
                        tabId: currentTabId
                    });
                } else {
                    attemptsWithoutNew++;
                    // Try nudging the scroll slightly up and down to re-trigger IntersectionObserver
                    window.scrollBy({ top: -350, behavior: 'smooth' });
                    window.dispatchEvent(new Event('scroll'));
                    await new Promise(r => setTimeout(r, 220));
                    window.scrollBy({ top: 400, behavior: 'smooth' });
                    window.dispatchEvent(new Event('scroll'));
                    await new Promise(r => setTimeout(r, 350));
                }

                if (pageHarvestedCount >= expectedPageLimit || (currentEstimatedTotal > 0 && sentLinks.size >= currentEstimatedTotal)) {
                    break;
                }
            }

            if (!isTabScrapingActive || !window.__tradeScoutIsScrapingActive) break;

            if (pageHarvestedCount > 0) {
                consecutiveNoNew = 0;
                lastCount = sentLinks.size;
            } else {
                consecutiveNoNew++;
            }

            // Refresh estimated total if higher count is discovered on subsequent pages
            const latestEstimated = getEstimatedTotalFromPage();
            if (latestEstimated > currentEstimatedTotal) {
                currentEstimatedTotal = latestEstimated;
            }

            const actionObj = findPaginationActionElements(currentPage);
            const hasNextPage = !!actionObj;

            // 2. Strict Check: finish only when target reached AND no further pages exist, or no next action
            if (currentEstimatedTotal > 0 && sentLinks.size >= currentEstimatedTotal && !hasNextPage) {
                console.log(`TradeScout Tab ${currentTabId}: Target count reached (${sentLinks.size}/${currentEstimatedTotal}) with no further pages. Finishing!`);
                break;
            }

            if (!hasNextPage && consecutiveNoNew >= 2) {
                console.log(`TradeScout Tab ${currentTabId}: No next page button found and no new products. Catalog complete.`);
                break;
            }

            // 3. Trigger next page via DOM click or Show More
            let pageTransitionSuccess = false;
            const maxTransitionAttempts = 3;

            for (let attempt = 1; attempt <= maxTransitionAttempts; attempt++) {
                if (!isTabScrapingActive || !window.__tradeScoutIsScrapingActive) break;

                const prevDomCount = document.querySelectorAll(tileSelectors).length;
                const actionObj = findPaginationActionElements(currentPage);

                if (actionObj) {
                    if (!isTabScrapingActive || !window.__tradeScoutIsScrapingActive) break;

                    currentStatusMsg = `Завантаження стор. ${currentPage + 1}...`;
                    sendTabMessage({
                        action: 'tabProgress',
                        total: sentLinks.size,
                        page: currentPage,
                        percent: currentPercent,
                        statusMsg: currentStatusMsg,
                        syncedCount: sentLinks.size,
                        estimatedTotal: currentEstimatedTotal,
                        sessionTitle: meta.title,
                        category: meta.category,
                        sessionId: currentSessionId,
                        startTime: sessionStartTime
                    });

                    // Scroll element into view before clicking
                    try {
                        actionObj.element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        await new Promise(r => setTimeout(r, 200));
                    } catch (_) {}

                    dispatchSafeClick(actionObj.element);

                    for (let w = 0; w < 16; w++) {
                        if (!isTabScrapingActive || !window.__tradeScoutIsScrapingActive) break;
                        await new Promise(r => setTimeout(r, 250));
                        
                        const currentDomCount = document.querySelectorAll(tileSelectors).length;
                        // Check if DOM expanded (Show More)
                        if (currentDomCount > prevDomCount) {
                            pageTransitionSuccess = true;
                            break;
                        }
                        // Check if new tiles loaded in DOM with unscraped links (Numbered Pagination)
                        const freshItems = Array.from(document.querySelectorAll(tileSelectors));
                        const hasUnscrapedLink = freshItems.some(tile => {
                            if (isUnwantedTile(tile)) return false;
                            const linkTag = tile.querySelector('a.goods-tile__heading, a.tile-title, a[href*="/p/"], a[href*="/p-"], a[href*="/p"]');
                            if (!linkTag) return false;
                            let href = linkTag.getAttribute('href') || '';
                            href = href.split('?')[0].split('#')[0].replace(/\/+$/, '');
                            return href && !sentLinks.has(href) && !sentLinks.has(`https://rozetka.com.ua${href}`);
                        });
                        if (hasUnscrapedLink) {
                            pageTransitionSuccess = true;
                            break;
                        }
                    }

                    if (pageTransitionSuccess) {
                        currentPage++;
                        consecutiveNoNew = 0;
                        // Reset scroll to top for the newly loaded page
                        window.scrollTo({ top: 0, behavior: 'auto' });
                        window.dispatchEvent(new Event('scroll'));
                        await new Promise(r => setTimeout(r, 400));
                        break;
                    }
                }

                if (attempt < maxTransitionAttempts) {
                    await silentBackgroundScroll();
                    await new Promise(r => setTimeout(r, 500));
                }
            }

            if (!pageTransitionSuccess) {
                consecutiveNoNew++;
                if (consecutiveNoNew >= 2) {
                    console.log(`TradeScout Tab ${currentTabId}: Catalog finished with ${sentLinks.size} items.`);
                    break;
                }
                await new Promise(r => setTimeout(r, 500));
            }
        }

        if (isTabScrapingActive && window.__tradeScoutIsScrapingActive) {
            isTabScrapingActive = false;
            window.__tradeScoutIsScrapingActive = false;
            currentPercent = 100;
            currentStatusMsg = `Збір завершено! Всього ${sentLinks.size} товарів.`;
            console.log(`TradeScout Tab ${currentTabId}: Scrape completed with ${sentLinks.size} items.`);

            sendTabMessage({
                action: 'tabFinished',
                total: sentLinks.size,
                page: currentPage,
                percent: 100,
                statusMsg: currentStatusMsg,
                syncedCount: sentLinks.size,
                estimatedTotal: sentLinks.size,
                sessionTitle: meta.title,
                category: meta.category,
                sessionId: currentSessionId
            });
        }
    }

    function startScrapingOnThisTab(tabId, customUrl) {
        isTabScrapingActive = true;
        window.__tradeScoutIsScrapingActive = true;
        currentTabId = tabId || currentTabId || Date.now();
        currentSessionId = `session_${currentTabId}_${Date.now()}`;
        if (customUrl) webhookEndpoint = customUrl;
        sentLinks.clear();
        sessionStartTime = Date.now();
        currentPage = 1;

        const meta = getPageMetadata();
        currentEstimatedTotal = getEstimatedTotalFromPage();
        currentPercent = 1;
        currentStatusMsg = `Запуск скрейпінгу: ${meta.title}...`;

        sendTabMessage({
            action: 'tabProgress',
            total: 0,
            page: 1,
            percent: 1,
            statusMsg: currentStatusMsg,
            sessionTitle: meta.title,
            category: meta.category,
            sessionId: currentSessionId,
            estimatedTotal: currentEstimatedTotal,
            startTime: sessionStartTime
        });

        runTabScraper(1);
    }

    function stopScrapingOnThisTab() {
        isTabScrapingActive = false;
        window.__tradeScoutIsScrapingActive = false;
        const meta = getPageMetadata();
        currentPercent = 0;
        currentStatusMsg = 'Скрейпінг зупинено.';

        sendTabMessage({
            action: 'tabStopped',
            total: sentLinks.size,
            page: currentPage,
            percent: 0,
            statusMsg: 'Скрейпінг зупинено.',
            sessionTitle: meta.title,
            category: meta.category,
            sessionId: currentSessionId
        });
    }

    function resetTabState() {
        isTabScrapingActive = false;
        window.__tradeScoutIsScrapingActive = false;
        sentLinks.clear();
        currentPercent = 0;
        currentEstimatedTotal = 0;
        currentStatusMsg = 'Готова до запуску';
        currentPage = 1;
        const meta = getPageMetadata();
        sendTabMessage({ action: 'tabIdle', sessionTitle: meta.title, category: meta.category });
    }

    // Default 100% idle on page load
    const initialMeta = getPageMetadata();
    sendTabMessage({ action: 'tabIdle', sessionTitle: initialMeta.title, category: initialMeta.category });

    // Expose direct window handlers for fail-safe invocation
    window.__tradeScoutStartScrape = startScrapingOnThisTab;
    window.__tradeScoutStopScrape = stopScrapingOnThisTab;
    window.__tradeScoutResetState = resetTabState;

    // Listen for clear events from dashboard window
    window.addEventListener('tradescout_reset_extension_sessions', resetTabState);
    window.addEventListener('message', (event) => {
        if (event.data && (event.data.type === 'TRADESCOUT_CLEAR_ALL' || event.data.action === 'RESET_ALL_SESSIONS')) {
            resetTabState();
        }
    });

    // Message listener for popup / background commands
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'START_TAB_SCRAPE') {
            startScrapingOnThisTab(message.tabId, message.webhookUrl);
            const meta = getPageMetadata();
            sendResponse({ success: true, sessionTitle: meta.title });
            return true;
        }

        if (message.action === 'STOP_TAB_SCRAPE') {
            stopScrapingOnThisTab();
            sendResponse({ success: true });
            return true;
        }

        if (message.action === 'RESET_TAB_STATE') {
            resetTabState();
            sendResponse({ success: true });
            return true;
        }

        if (message.action === 'PING_TAB_STATUS') {
            const meta = getPageMetadata();
            const est = getEstimatedTotalFromPage();
            const isRunning = isTabScrapingActive && window.__tradeScoutIsScrapingActive;
            const isFinished = !isRunning && currentPercent === 100 && sentLinks.size > 0;
            const finalEst = isFinished ? sentLinks.size : (currentEstimatedTotal > 0 ? currentEstimatedTotal : est);

            sendResponse({
                isRunning: isRunning,
                totalScraped: sentLinks.size,
                estimatedTotal: finalEst,
                percent: currentPercent,
                statusMsg: currentStatusMsg,
                page: currentPage,
                startTime: sessionStartTime,
                sessionTitle: meta.title,
                category: meta.category,
                sessionId: currentSessionId
            });
            return true;
        }
    });

})();
